package com.bmpl.AnnotationQualifiers;

public interface Z {
	public String show();
	public String print();
}
