package com.bmpl.AnnotationQualifiers;

public interface Y {
	public String print();

}
