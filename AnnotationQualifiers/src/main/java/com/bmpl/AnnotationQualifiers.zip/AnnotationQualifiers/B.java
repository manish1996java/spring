package com.bmpl.AnnotationQualifiers;

import org.springframework.stereotype.Component;

@Component
public class B implements Y{
	
	//Default constructor
	public B() {
		System.out.println("B Constructor");
	}
	
	public String print()
	{	
	return "B print method";
	}
}
